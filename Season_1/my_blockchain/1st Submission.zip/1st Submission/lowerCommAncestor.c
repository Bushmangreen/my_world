#include "headers.h"

int lowerCommAncestor(GlobalNode*  nodes)
{
   return 0;
}

int depthFirstSearch(GlobalNode* nodes)
{
    return 0;
}