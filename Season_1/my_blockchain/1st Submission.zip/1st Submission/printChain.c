#include "headers.h"

int printChain(GlobalNode* nodes)
{
    int a = nodes->cap;
    return a;
}