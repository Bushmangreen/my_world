

#include "my_tar.h"

int main(int argc, char *argv[])
{
    int fd = open(argv[2], O_CREAT | O_APPEND |  O_WRONLY  , 0644);
    int i = 3;
    while (i <= 4)
    
        create_archive(fd, argv[i++]);
    
    end_of_archive(fd);
    close(fd);
    return 0;
}




/*
    t_opt* opt = get_opt(argc,argv);
    print_opt(opt);
    free(opt);
*/