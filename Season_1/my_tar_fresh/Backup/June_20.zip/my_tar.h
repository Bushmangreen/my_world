
#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <string.h>
#include <strings.h>
#include <pwd.h>
#include <grp.h>

#define TMAGIC   "ustar"        /* ustar and a null */
#define TMAGLEN  6
#define TVERSION "00"           /* 00 and no null */
#define TVERSLEN 2

/* Values used in typeflag field.  */
#define REGTYPE  '0'            /* regular file */
#define AREGTYPE '\0'           /* regular file */
#define LNKTYPE  '1'            /* link */
#define SYMTYPE  '2'            /* reserved */
#define CHRTYPE  '3'            /* character special */
#define BLKTYPE  '4'            /* block special */
#define DIRTYPE  '5'            /* directory */
#define FIFOTYPE '6'            /* FIFO special */
#define CONTTYPE '7'            /* reserved */

#define XHDTYPE  'x'            /* Extended header referring to the
                                   next file in the archive */
#define XGLTYPE  'g'            /* Global extended header */

/* Bits used in the mode field, values in octal.  */
#define TSUID    04000          /* set UID on execution */
#define TSGID    02000          /* set GID on execution */
#define TSVTX    01000          /* reserved */
                                /* file permissions */
#define TUREAD   00400          /* read by owner */
#define TUWRITE  00200          /* write by owner */
#define TUEXEC   00100          /* execute/search by owner */
#define TGREAD   00040          /* read by group */
#define TGWRITE  00020          /* write by group */
#define TGEXEC   00010          /* execute/search by group */
#define TOREAD   00004          /* read by other */
#define TOWRITE  00002          /* write by other */
#define TOEXEC   00001          /* execute/search by other */


typedef struct t_opt
{
	int c;
    int f;
	int r;
	int t;
	int u;
	int x; 
    int error;
}t_opt;

typedef struct posix_header
{				/* byte offset */
	char name[100];		/*   0 */
	char mode[8];			/* 100 */
	char uid[8];			/* 108 */
	char gid[8];			/* 116 */
	char size[12];		/* 124 */
	char mtime[12];		/* 136 */
	char chksum[8];		/* 148 */
	char typeflag;		/* 156 */
	char linkname[100];		/* 157 */
	char magic[6];		/* 257 */
	char version[2];		/* 263 */
	char uname[32];		/* 265 */
	char gname[32];		/* 297 */
	char devmajor[8];		/* 329 */
	char devminor[8];		/* 337 */
	char prefix[155];		/* 345 */
	
				/* 500 */
}tar_header;

t_opt* get_opt(int argc, char *argv[]);
void print_opt(t_opt* opt);
int print_error(void);
int str_search(char* str, char* search);
tar_header* init_tar_header();
int get_file_size(int fd);
int write_file_content(int fd_archive, char* file_name);
tar_header* get_meta_data(char* file_name);
int open_flags(t_opt* opt);
int get_file_size(int fd);
int write_to_stdout(int fd_archive, char* file_name);

void end_of_archive(int fd);
char* itoa(char* res, unsigned int number, int size, int base);
void fill_name(char* header, char* name, int size);
void fill_mode(char* header, int st_mode, int size);
void fill_num(char* header, char* file_info, int size);
void fill_size(char* header, char* file_info, int size);
void fill_spaces(char* header);
char file_type(struct stat *buf);
void fill_linkname(char *header, char *str, struct stat *buf);
void fill_version(char* header, int size);
void fill_magic(char* header, char* magic);
void fill_uid(char *header, struct stat *buf, char type);
void fill_prefix(char* header, char end_of_string, int size);
void fill_checksum(char* header, int sum, int size);
int create_archive(int fd_archive, char* file_name);
